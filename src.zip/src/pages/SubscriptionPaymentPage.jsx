// import { useEffect } from "react";
// import { useNavigate, useParams, useLocation } from "react-router-dom";
// import { useQuery } from "@tanstack/react-query";
// import { ChevronLeft, Wallet, AlertCircle, CheckCircle, ChefHat, Calendar, Zap } from "lucide-react";
// import { motion } from "framer-motion";

// // Import from your api.js — adjust path if needed
// import { getWalletBalance } from "../services/api";

// const formatPrice = (price) =>
//   Number(price)
//     .toFixed(2)
//     .replace(/\B(?=(\d{3})+(?!\d))/g, ",");

// const SubscriptionPaymentPage = () => {
//   const navigate = useNavigate();
//   const { planId } = useParams();
//   const { state } = useLocation();

//   const plan = state?.plan;
//   const vendor = state?.vendor;

//   // If no state was passed (e.g. direct URL navigation), go back
//   useEffect(() => {
//     if (!plan || !planId) {
//       navigate(-1);
//     }
//   }, [plan, planId, navigate]);

//   const { data: wallet, isLoading: walletLoading } = useQuery({
//     queryKey: ["walletBalance"],
//     queryFn: getWalletBalance,
//   });

//   const planPrice = parseFloat(plan?.price || 0);
//   const walletBalance = parseFloat(wallet?.balance_naira || 0);
//   const hasEnoughBalance = walletBalance >= planPrice;

//   const platformFee = planPrice * 0.1;
//   const vendorReceives = planPrice * 0.9;

//   const handlePayWithWallet = () => {
//     navigate("/subscription/processing", {
//       state: {
//         planId,
//         plan,
//         vendor,
//       },
//     });
//   };

//   const handleTopUp = () => {
//     navigate("/wallet/topup");
//   };

//   if (!plan) return null;

//   return (
//     <div className="flex flex-col min-h-screen max-w-xl mx-auto bg-[#f6f8f6]">
//       {/* Header */}
//       <div className="relative bg-white px-4 py-4 border-b border-gray-100 flex items-center justify-center flex-shrink-0">
//         <button
//           onClick={() => navigate(-1)}
//           className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800 transition-colors"
//         >
//           <ChevronLeft size={24} />
//         </button>
//         <h1 className="text-lg font-bold text-[#111813]">Confirm Payment</h1>
//       </div>

//       <div className="flex-1 p-4 space-y-4 overflow-y-auto pb-32">
//         {/* Vendor + Plan Summary Card */}
//         <motion.div
//           initial={{ opacity: 0, y: 16 }}
//           animate={{ opacity: 1, y: 0 }}
//           className="bg-white rounded-2xl p-4 shadow-sm"
//         >
//           <div className="flex items-center gap-3 mb-4">
//             <div className="w-12 h-12 rounded-xl bg-[#13ec49]/10 flex items-center justify-center">
//               <ChefHat size={22} className="text-[#13ec49]" />
//             </div>
//             <div>
//               <p className="text-sm text-gray-500">Subscribing to</p>
//               <p className="font-bold text-[#111813] text-base">{vendor?.name || "Vendor"}</p>
//             </div>
//           </div>

//           <div className="border-t border-gray-100 pt-4 space-y-3">
//             <div className="flex items-center justify-between">
//               <span className="text-gray-500 text-sm">Plan</span>
//               <span className="font-semibold text-[#111813] text-sm">{plan?.plan_name}</span>
//             </div>
//             <div className="flex items-center justify-between">
//               <span className="text-gray-500 text-sm flex items-center gap-1">
//                 <Calendar size={14} /> Frequency
//               </span>
//               <span className="font-semibold text-[#111813] text-sm capitalize">
//                 {plan?.frequency || "Weekly"}
//               </span>
//             </div>
//             {plan?.meals_per_cycle && (
//               <div className="flex items-center justify-between">
//                 <span className="text-gray-500 text-sm">Meals per cycle</span>
//                 <span className="font-semibold text-[#111813] text-sm">{plan.meals_per_cycle}</span>
//               </div>
//             )}
//             {plan?.trial_days > 0 && (
//               <div className="flex items-center justify-between">
//                 <span className="text-gray-500 text-sm flex items-center gap-1">
//                   <Zap size={14} className="text-yellow-500" /> Trial period
//                 </span>
//                 <span className="font-semibold text-green-600 text-sm">
//                   {plan.trial_days} days free
//                 </span>
//               </div>
//             )}
//           </div>
//         </motion.div>

//         {/* Price Breakdown */}
//         <motion.div
//           initial={{ opacity: 0, y: 16 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.1 }}
//           className="bg-white rounded-2xl p-4 shadow-sm"
//         >
//           <p className="font-semibold text-[#111813] mb-3">Price Breakdown</p>
//           <div className="space-y-2">
//             <div className="flex items-center justify-between">
//               <span className="text-gray-500 text-sm">Subscription price</span>
//               <span className="font-semibold text-[#111813]">₦{formatPrice(planPrice)}</span>
//             </div>
//             <div className="flex items-center justify-between">
//               <span className="text-gray-400 text-xs">Platform fee (10%)</span>
//               <span className="text-gray-400 text-xs">₦{formatPrice(platformFee)}</span>
//             </div>
//             <div className="flex items-center justify-between">
//               <span className="text-gray-400 text-xs">Vendor receives (90%)</span>
//               <span className="text-gray-400 text-xs">₦{formatPrice(vendorReceives)}</span>
//             </div>
//             <div className="border-t border-gray-100 pt-2 mt-2 flex items-center justify-between">
//               <span className="font-bold text-[#111813]">You pay</span>
//               <span className="font-bold text-[#13ec49] text-lg">₦{formatPrice(planPrice)}</span>
//             </div>
//           </div>
//         </motion.div>

//         {/* Wallet Balance Card */}
//         <motion.div
//           initial={{ opacity: 0, y: 16 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.2 }}
//           className={`rounded-2xl p-4 shadow-sm ${
//             hasEnoughBalance
//               ? "bg-white"
//               : "bg-red-50 border border-red-100"
//           }`}
//         >
//           <div className="flex items-center justify-between">
//             <div className="flex items-center gap-2">
//               <div
//                 className={`w-10 h-10 rounded-xl flex items-center justify-center ${
//                   hasEnoughBalance ? "bg-[#13ec49]/10" : "bg-red-100"
//                 }`}
//               >
//                 <Wallet
//                   size={20}
//                   className={hasEnoughBalance ? "text-[#13ec49]" : "text-red-500"}
//                 />
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Lily Wallet Balance</p>
//                 {walletLoading ? (
//                   <div className="h-5 w-20 bg-gray-100 rounded animate-pulse mt-1" />
//                 ) : (
//                   <p className="font-bold text-[#111813]">
//                     ₦{formatPrice(walletBalance)}
//                   </p>
//                 )}
//               </div>
//             </div>
//             {!walletLoading && (
//               <div>
//                 {hasEnoughBalance ? (
//                   <div className="flex items-center gap-1 bg-green-50 text-green-600 text-xs font-semibold px-2 py-1 rounded-full">
//                     <CheckCircle size={12} />
//                     Sufficient
//                   </div>
//                 ) : (
//                   <div className="flex items-center gap-1 bg-red-100 text-red-500 text-xs font-semibold px-2 py-1 rounded-full">
//                     <AlertCircle size={12} />
//                     Insufficient
//                   </div>
//                 )}
//               </div>
//             )}
//           </div>

//           {!walletLoading && !hasEnoughBalance && (
//             <div className="mt-3 p-3 bg-red-100 rounded-xl">
//               <p className="text-red-600 text-xs">
//                 You need{" "}
//                 <strong>₦{formatPrice(planPrice - walletBalance)}</strong> more
//                 to subscribe to this plan. Top up your wallet to continue.
//               </p>
//             </div>
//           )}
//         </motion.div>

//         {/* Payment method note */}
//         <motion.div
//           initial={{ opacity: 0, y: 16 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.3 }}
//           className="flex items-start gap-2 bg-blue-50 rounded-2xl p-4"
//         >
//           <AlertCircle size={16} className="text-blue-400 mt-0.5 flex-shrink-0" />
//           <p className="text-blue-600 text-xs leading-relaxed">
//             Food subscriptions are paid using your Lily Wallet balance. The amount will be deducted
//             immediately upon confirmation.
//           </p>
//         </motion.div>
//       </div>

//       {/* Bottom CTA */}
//       <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-xl bg-white border-t border-gray-100 p-4 space-y-3">
//         {hasEnoughBalance ? (
//           <motion.button
//             whileTap={{ scale: 0.97 }}
//             onClick={handlePayWithWallet}
//             disabled={walletLoading}
//             className="w-full bg-[#13ec49] text-[#111813] font-bold py-4 rounded-2xl text-base disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95"
//           >
//             {walletLoading ? "Checking balance..." : `Pay ₦${formatPrice(planPrice)} with Wallet`}
//           </motion.button>
//         ) : (
//           <>
//             <motion.button
//               whileTap={{ scale: 0.97 }}
//               onClick={handleTopUp}
//               className="w-full bg-[#13ec49] text-[#111813] font-bold py-4 rounded-2xl text-base transition-all active:scale-95"
//             >
//               Top Up Wallet
//             </motion.button>
//             <button
//               onClick={() => navigate(-1)}
//               className="w-full bg-white text-gray-500 font-semibold py-3 rounded-2xl text-sm border border-gray-200"
//             >
//               Go Back
//             </button>
//           </>
//         )}
//       </div>
//     </div>
//   );
// };

// export default SubscriptionPaymentPage;



import { useEffect } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, Wallet, AlertCircle, CheckCircle, ChefHat, Calendar, Zap } from "lucide-react";
import { motion } from "framer-motion";

// Import from your api.js — adjust path if needed
import { getWalletBalance } from "../services/api";

const formatPrice = (price) =>
  Number(price)
    .toFixed(2)
    .replace(/\B(?=(\d{3})+(?!\d))/g, ",");

const SubscriptionPaymentPage = () => {
  const navigate = useNavigate();
  const { planId } = useParams();
  const { state } = useLocation();

  const plan = state?.plan;
  const vendor = state?.vendor;

  // If no state was passed (e.g. direct URL navigation), go back
  useEffect(() => {
    if (!plan || !planId) {
      navigate(-1);
    }
  }, [plan, planId, navigate]);

  const { data: wallet, isLoading: walletLoading } = useQuery({
    queryKey: ["walletBalance"],
    queryFn: getWalletBalance,
  });

  const planPrice = parseFloat(plan?.price || 0);
  const walletBalance = parseFloat(wallet?.balance_naira || 0);
  const hasEnoughBalance = walletBalance >= planPrice;

  const platformFee = planPrice * 0.1;
  const vendorReceives = planPrice * 0.9;

  const handlePayWithWallet = () => {
    navigate("/subscription/processing", {
      state: {
        planId,
        plan,
        vendor,
      },
    });
  };

  const handleTopUp = () => {
    navigate("/wallet/topup");
  };

  if (!plan) return null;

  return (
    <div className="flex flex-col min-h-screen max-w-xl mx-auto bg-[#f6f8f6]">
      {/* Header */}
      <div className="relative bg-white px-4 py-4 border-b border-gray-100 flex items-center justify-center flex-shrink-0">
        <button
          onClick={() => navigate(-1)}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ChevronLeft size={24} />
        </button>
        <h1 className="text-lg font-bold text-[#111813]">Confirm Payment</h1>
      </div>

      <div className="flex-1 p-4 space-y-4 overflow-y-auto pb-32">
        {/* Vendor + Plan Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-4 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-[#13ec49]/10 flex items-center justify-center">
              <ChefHat size={22} className="text-[#13ec49]" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Subscribing to</p>
              <p className="font-bold text-[#111813] text-base">{vendor?.name || "Vendor"}</p>
            </div>
          </div>

          <div className="border-t border-gray-100 pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-500 text-sm">Plan</span>
              <span className="font-semibold text-[#111813] text-sm">{plan?.plan_name}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-500 text-sm flex items-center gap-1">
                <Calendar size={14} /> Frequency
              </span>
              <span className="font-semibold text-[#111813] text-sm capitalize">
                {plan?.frequency || "Weekly"}
              </span>
            </div>
            {plan?.meals_per_cycle && (
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-sm">Meals per cycle</span>
                <span className="font-semibold text-[#111813] text-sm">{plan.meals_per_cycle}</span>
              </div>
            )}
            {plan?.trial_days > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-sm flex items-center gap-1">
                  <Zap size={14} className="text-yellow-500" /> Trial period
                </span>
                <span className="font-semibold text-green-600 text-sm">
                  {plan.trial_days} days free
                </span>
              </div>
            )}
          </div>
        </motion.div>

        {/* Price Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-4 shadow-sm"
        >
          <p className="font-semibold text-[#111813] mb-3">Price Breakdown</p>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-gray-500 text-sm">Subscription price</span>
              <span className="font-semibold text-[#111813]">₦{formatPrice(planPrice)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-xs">Platform fee (10%)</span>
              <span className="text-gray-400 text-xs">₦{formatPrice(platformFee)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-xs">Vendor receives (90%)</span>
              <span className="text-gray-400 text-xs">₦{formatPrice(vendorReceives)}</span>
            </div>
            <div className="border-t border-gray-100 pt-2 mt-2 flex items-center justify-between">
              <span className="font-bold text-[#111813]">You pay</span>
              <span className="font-bold text-[#13ec49] text-lg">₦{formatPrice(planPrice)}</span>
            </div>
          </div>
        </motion.div>

        {/* Wallet Balance Card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`rounded-2xl p-4 shadow-sm ${
            hasEnoughBalance
              ? "bg-white"
              : "bg-red-50 border border-red-100"
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  hasEnoughBalance ? "bg-[#13ec49]/10" : "bg-red-100"
                }`}
              >
                <Wallet
                  size={20}
                  className={hasEnoughBalance ? "text-[#13ec49]" : "text-red-500"}
                />
              </div>
              <div>
                <p className="text-xs text-gray-500">Lily Wallet Balance</p>
                {walletLoading ? (
                  <div className="h-5 w-20 bg-gray-100 rounded animate-pulse mt-1" />
                ) : (
                  <p className="font-bold text-[#111813]">
                    ₦{formatPrice(walletBalance)}
                  </p>
                )}
              </div>
            </div>
            {!walletLoading && (
              <div>
                {hasEnoughBalance ? (
                  <div className="flex items-center gap-1 bg-green-50 text-green-600 text-xs font-semibold px-2 py-1 rounded-full">
                    <CheckCircle size={12} />
                    Sufficient
                  </div>
                ) : (
                  <div className="flex items-center gap-1 bg-red-100 text-red-500 text-xs font-semibold px-2 py-1 rounded-full">
                    <AlertCircle size={12} />
                    Insufficient
                  </div>
                )}
              </div>
            )}
          </div>

          {!walletLoading && !hasEnoughBalance && (
            <div className="mt-3 p-3 bg-red-100 rounded-xl">
              <p className="text-red-600 text-xs">
                You need{" "}
                <strong>₦{formatPrice(planPrice - walletBalance)}</strong> more
                to subscribe to this plan. Top up your wallet to continue.
              </p>
            </div>
          )}
        </motion.div>

        {/* Payment method note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-start gap-2 bg-blue-50 rounded-2xl p-4"
        >
          <AlertCircle size={16} className="text-blue-400 mt-0.5 flex-shrink-0" />
          <p className="text-blue-600 text-xs leading-relaxed">
            Food subscriptions are paid using your Lily Wallet balance. The amount will be deducted
            immediately upon confirmation.
          </p>
        </motion.div>
      </div>

      {/* Bottom CTA */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-xl bg-white border-t border-gray-100 p-4 space-y-3">
        {hasEnoughBalance ? (
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handlePayWithWallet}
            disabled={walletLoading}
            className="w-full bg-[#13ec49] text-[#111813] font-bold py-4 rounded-2xl text-base disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95"
          >
            {walletLoading ? "Checking balance..." : `Pay ₦${formatPrice(planPrice)} with Wallet`}
          </motion.button>
        ) : (
          <>
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={handleTopUp}
              className="w-full bg-[#13ec49] text-[#111813] font-bold py-4 rounded-2xl text-base transition-all active:scale-95"
            >
              Top Up Wallet
            </motion.button>
            <button
              onClick={() => navigate(-1)}
              className="w-full bg-white text-gray-500 font-semibold py-3 rounded-2xl text-sm border border-gray-200"
            >
              Go Back
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default SubscriptionPaymentPage;